# Creates full-range overview plots (collection assumed open).

set_var COLLDIR  = /Users/user/Documents/R/Urea
set_var COLLNAME = urea_uptake_stn
set_var VIEWSDIR = %COLLDIR%/%COLLNAME%.Data/views/_overviews

load_view %VIEWSDIR%/OVERVIEW_AllStationsMap.xview
export_graphics -1, %COLLDIR%/%COLLNAME%_OVERVIEW_AllStationsMap.gif, 300

load_view %VIEWSDIR%/OVERVIEW_vars_0002-0018.xview
set_axis_full_ranges -1
set_axis_full_ranges 0
save_view %VIEWSDIR%/OVERVIEW_vars_0002-0018.xview
export_graphics -1, %COLLDIR%/%COLLNAME%_OVERVIEW_vars_0002-0018.gif, 300

